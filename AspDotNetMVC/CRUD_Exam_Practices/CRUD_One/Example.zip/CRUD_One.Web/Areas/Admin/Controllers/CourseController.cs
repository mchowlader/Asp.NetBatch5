﻿using CRUD_One.Web.Areas.Admin.Models;
using ExamTimeChallenge.Web.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD_One.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CourseController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            var model = new CreateCourseModel();
            return View(model);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(CreateCourseModel model)
        {
            model.CreateCourse();
            return View(model);
        }

        public IActionResult Data()
        {
            return View();
        }
        public JsonResult GetCourse()
        {
            var dataTableModel = new DataTablesAjaxRequestModel(Request);
            var model = new ListCourseModel();
            var data = model.loadModelData(dataTableModel);
           
            return Json(data);
        }


        public IActionResult Edit(int id)
        {
            var model = new EditCourseModel();
            model.LoadModelData(id);
            return View(model);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(EditCourseModel model)
        {
            model.UpdateCourse();
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            var model = new ListCourseModel();
            model.Delete(id);
            return RedirectToAction(nameof(Data));
        }

    }
}
