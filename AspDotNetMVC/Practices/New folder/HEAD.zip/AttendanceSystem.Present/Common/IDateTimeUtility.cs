﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceSystem.Present.Common
{
    public interface IDateTimeUtility
    {
        DateTime Now { get; set; }
    }
}
